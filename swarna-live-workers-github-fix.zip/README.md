# Swarna Live — Cloudflare WORKERS GitHub deployment fix

## What went wrong?

Your Cloudflare screenshot says:
    [ERROR] Uploading a Pages _worker.js file as an asset.

This happens when a Cloudflare **Workers** static-assets deployment takes the
entire GitHub repository as its public static-assets directory. `_worker.js`
is reserved for **Pages** advanced mode and must not be uploaded as a public
asset. Simply adding an empty `.assetsignore` does not configure backend APIs.

This package uses the recommended **Workers** structure instead:

    wrangler.jsonc       Worker configuration (at GitHub repo root)
    src/worker.js        Server-side backend for /api/health and /api/rates
    public/index.html    Public frontend HTML

No _worker.js appears in the public assets folder.

## Use GitHub (the deployment method shown in the screenshot)

1. Download this ZIP, then EXTRACT it. Do not upload the ZIP as one GitHub file.
2. In the exact GitHub repository connected to Cloudflare's `swarna-live`
   Worker, upload these three files, PRESERVING their folder paths:
      - wrangler.jsonc
      - src/worker.js
      - public/index.html
3. If the repository contains the previous root `_worker.js` file, remove
   that obsolete file. If you have other website assets (CSS, photos, other
   HTML), move any assets needed by this site into the `public/` directory.
4. Commit to the branch that is connected to your Cloudflare Worker.
5. In Cloudflare Dashboard > Workers & Pages > swarna-live > Settings > Builds,
   ensure the deploy command is `npx wrangler deploy` (not `npx wrangler deploy
   --assets .` or similar), and ensure the configured root directory is the
   directory with wrangler.jsonc. Your Cloudflare UI may label settings slightly
   differently.
6. Allow Cloudflare to deploy that commit, or retry the failed build once the
   configuration is committed.
7. Test https://swarnalive.com/api/health . It should return JSON with
   `"ok":true` and `"backend":"Cloudflare Worker (src/worker.js)"`.
8. Test https://swarnalive.com/api/rates . Successful responses include live
   rates; a JSON error indicates the Goodreturns site blocked requests or
   changed its page markup, not necessarily another Cloudflare deployment error.

## Important limits

- These source pages are NOT APIs. Goodreturns can block automated access or
  change HTML, which would make price retrieval fail even after this deploy.
- Rate-checking in the browser is every one second, but the Worker caches
  successful publisher responses for 300 seconds. The page does not make the
  source publish new prices every second.
- Public gold/silver rates are indicative only and can be unavailable. The app
  does NOT fabricate prices. Always verify before using prices in transactions.
- A 1-second browser poll may count against Cloudflare's Workers usage quota.
- Do not put API secrets/passwords/keys in `public/` or committed source code.

## If you intentionally deploy as Cloudflare Pages instead

The earlier `_worker.js` package was designed for Pages advanced mode. For
Pages, the `_worker.js` must be in the Pages build-output directory and Pages
must be deployed using a Pages workflow (`wrangler pages deploy ...`), not the
Workers `wrangler deploy` shown by the error in the screenshot. Do not mix
these two deployment methods.
